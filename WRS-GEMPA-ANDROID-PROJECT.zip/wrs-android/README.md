# WRS Gempa Android Test Project

Native Android Trusted Web Activity wrapper for https://wrsgempa.netlify.app/.

The project intentionally uses a debug APK for testing. Production signing and Digital Asset Links can be added later.
